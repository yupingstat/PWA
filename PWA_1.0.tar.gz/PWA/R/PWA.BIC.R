PWA.BIC = function(x, obj){
	df.a = sum(obj$a !=0)
	df.theta = sum(obj$theta!=0)
	missing <- is.na(x)
	npt = sum(!missing)
	if(is.array(x)){	
		N = dim(x)[1]
		P = dim(x)[2]
		T = dim(x)[3]
		prd = array(NA, dim=c(N, P, T))
		for(jj in 1:N){
		  prd[jj,,] = obj$prd;	
    }
    loss = sum((x-prd)[!missing]^2)/npt
	}
	if(is.matrix(x)){
		loss = sum((x-obj$prd)[!missing]^2)/npt  
	}
	BIC = log(loss) + log(npt)/(npt)*(df.a + df.theta)
	return(BIC) 
}

