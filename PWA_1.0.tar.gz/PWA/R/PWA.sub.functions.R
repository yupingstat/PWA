library(wavethresh)

wavelet.theta.func = function(a, x, W, d){
  N = dim(x)[1]
  T = dim(x)[3]
  theta =  W %*% t(apply(x, c(2,3), sum)) %*% a %*% matrix(d, 1,1)
  return(theta)
}

wavelet.fea.func = function(theta, x, W, d){
   a =  apply(x, c(2,3), sum) %*% t(W) %*% theta %*% matrix(d, 1,1)
}
  
wavelet.d.func = function(a, theta, x, W){
  N = dim(x)[1]
  d = (t(theta) %*% W %*% t(apply(x, c(2,3), sum)) %*% a)/N
}

soft <- function(vec,lam){
  return(sign(vec)*pmax(0,abs(vec)-lam))
}


l2n <- function(vec){
  return(sqrt(sum(vec^2)))
}


BinarySearch <- function(argu,sumabs){
  if(l2n(argu)==0 || sum(abs(argu/l2n(argu)))<=sumabs) return(0)
  lam1 <- 0
  lam2 <- max(abs(argu))-1e-5
  iter <- 1
  while(iter < 150){
    su <- soft(argu,(lam1+lam2)/2)
    if(sum(abs(su/l2n(su)))<sumabs){
      lam2 <- (lam1+lam2)/2
    } else {
      lam1 <- (lam1+lam2)/2
    }
    if((lam2-lam1)<1e-6) return((lam1+lam2)/2)
    iter <- iter+1
  }
  warning("Didn't quite converge")
  return((lam1+lam2)/2)
}


