## N*P*T   
PWA = function(x, niter=6, sumabsa, sumabstheta, topfea.flag=TRUE, topfea, toptheta.flag = FALSE, toptheta, filter.number = 1, family = "DaubExPhase"){
  ## time is ordered increasingly
  N = dim(x)[1]
  P = dim(x)[2]
  T = dim(x)[3]
  W = t(GenW(n=T, filter.number = filter.number, family = family))
  
  theta.length = nrow(W)
  
  xoo = x
  xoo[is.na(x)] = mean(x[!is.na(x)])
  xm = matrix(nrow=P, ncol=T)

  if(N==1){xm = xoo[1,,]}
  if(N>1){xm = apply(xoo, c(2,3), mean, na.rm=TRUE)}

  a = matrix(svd(xm)$u[, 1], ncol=1)
  d = matrix(1, nrow=1, ncol=1)
  x = xoo
  rm(xoo)
 
  if((topfea.flag == TRUE) && (toptheta.flag == TRUE)){
    iter = 1
    while(iter < (niter +1)){
      cat(iter, fill=F)
      theta_new = wavelet.theta.func(a, x, W, d)
      if(toptheta < theta.length){
        theta.dec = sort(abs(theta_new), decreasing = TRUE)
        if((theta.dec[toptheta] > theta.dec[toptheta+1])){lambda_theta = theta.dec[toptheta+1]}else{
          cat("theta.dec[toptheta] == theta.dec[toptheta+1]\n")
          lambda_theta = lamtheta[toptheta+1]-1e-6
        }
        theta_new = matrix(soft(theta_new, lambda_theta), ncol=1)
      }
      theta_new = matrix(theta_new/l2n(theta_new), ncol=1)
      theta =  theta_new 
      a_new = wavelet.fea.func(theta, x, W, d)
      if(topfea<P){
        a.dec = sort(abs(a_new[,1]), decreasing=TRUE)
        if(a.dec[topfea]>a.dec[topfea+1]){lamu = a.dec[topfea+1]}else{
          cat("a.dec[topfea] == a.dec[topfea+1]\n") 
          lamu = a.dec[topfea+1]-1e-6
        }
        a_new[,1] = matrix(soft(a_new[,1], lamu), ncol=1)
      }
      a_new = matrix(a_new/l2n(a_new), ncol=1)
      a = a_new
      d = wavelet.d.func(a, theta, x, W)
      iter = iter + 1
    }
  }
  
  if((topfea.flag == TRUE) && (toptheta.flag == FALSE)){
    sumabstheta = sqrt(T)*sumabstheta
    iter = 1
    while(iter < (niter +1)){
      cat(iter, fill=F)
      theta_new = wavelet.theta.func(a, x, W, d)
      lambda_theta = BinarySearch(theta_new, sumabstheta)
      theta_new = matrix(soft(theta_new, lambda_theta), ncol=1)
      theta_new = matrix(theta_new/l2n(theta_new), ncol=1)
      theta =  theta_new 
      a_new = wavelet.fea.func(theta, x, W, d)
      if(topfea<P){
        a.dec = sort(abs(a_new[,1]), decreasing=TRUE)
        if(a.dec[topfea]>a.dec[topfea+1]){lamu = a.dec[topfea+1]}else{
          cat("a.dec[topfea] == a.dec[topfea+1]\n") 
          lamu = a.dec[topfea+1]-1e-6
        }
        a_new[,1] = matrix(soft(a_new[,1], lamu), ncol=1)
      }
      a_new = matrix(a_new/l2n(a_new), ncol=1)
      a = a_new
      d = wavelet.d.func(a, theta, x, W)
      iter = iter + 1
    }
  }
  if((topfea.flag == FALSE) && (toptheta.flag == FALSE)){
    sumabstheta = sqrt(T)*sumabstheta
    sumabsa = sqrt(P)*sumabsa
    iter = 1
    while(iter < (niter +1)){
      cat(iter, fill=F)
      theta_new = wavelet.theta.func(a, x, W, d)
      lambda_theta = BinarySearch(theta_new, sumabstheta)
      theta_new = matrix(soft(theta_new, lambda_theta), ncol=1)
      theta_new = matrix(theta_new/l2n(theta_new), ncol=1)
      theta =  theta_new 
      a_new = wavelet.fea.func(theta, x, W, d)    
      lamu = BinarySearch(a_new, sumabsa)
      a_new[,1] = matrix(soft(a_new[,1], lamu)/l2n(soft(a_new[,1],lamu)), ncol=1)
      a = a_new
      d = wavelet.d.func(a, theta, x, W)
      iter = iter + 1
    }
  }
  
  out = list(a = a, theta=theta, d=d,  W=W, S=t( t(theta) %*% W ), prd = a %*% matrix(d,1,1) %*% t(theta) %*% W)
  return(out)
}


